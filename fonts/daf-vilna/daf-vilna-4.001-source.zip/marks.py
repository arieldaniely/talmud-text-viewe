"""Original vowel and cantillation drawings. Mark coordinates are local."""

import unicodedata


def dot(x, y, radius=2.2):
    r = radius
    return (f'M{x-r} {y} Q{x-r} {y-r} {x} {y-r} Q{x+r} {y-r} {x+r} {y} '
            f'Q{x+r} {y+r} {x} {y+r} Q{x-r} {y+r} {x-r} {y} Z ')


def rect(x, y, width, height):
    return f'M{x} {y} h{width} v{height} h{-width} Z '


def ring(x, y, radius=4.3):
    return dot(x, y, radius) + '|' + dot(x, y, radius - 1.55)


def arc(x=0, turn=0):
    forms = (
        'M-5 5 Q-4 -5 5 -5 V-2 Q-2 -2 -2 5 Z',
        'M-5 -5 Q5 -4 5 5 H2 Q2 -2 -5 -2 Z',
        'M-5 -5 H-2 Q-2 2 5 2 V5 Q-5 4 -5 -5 Z',
        'M5 -5 Q4 5 -5 5 V2 Q2 2 2 -5 Z',
    )
    path = forms[turn]
    if not x:
        return path
    return f'M{x-5} 5 Q{x-4} -5 {x+5} -5 V-2 Q{x-2} -2 {x-2} 5 Z' if turn == 0 else (
        f'M{x+5} -5 Q{x+4} 5 {x-5} 5 V2 Q{x+2} 2 {x+2} -5 Z')


S = 'M-7 3 C-10 -1 -6 -5 -2 -4 Q1 -3 3 1 Q6 5 8 1 Q9 -1 6 -3 L8 -5 Q13 -1 10 3 Q6 8 1 3 L-3 -1 Q-7 -3 -5 2 Z'
CHEVRON = 'M2 -5 H6 L1 0 L6 5 H2 L-3 0 Z'
FORK = 'M-5 -5 H-2 V-2 Q-2 1 0 1 Q2 1 2 -2 V-5 H5 V-2 Q5 3 1.4 4 V7 H-1.4 V4 Q-5 3 -5 -2 Z'
ANGLE = 'M2 -5 H5 V5 H-3 V2 H2 Z'
QAMATS = rect(-6, 0, 12, 2.5) + rect(-1.45, 1.5, 2.9, 6.5)

# Each accent has its conventional direction and outline. Unicode combining
# classes 222 and 228 are leading/trailing in reading order, which is RTL.
ACCENTS = dict(zip(range(0x0591, 0x05B0), (
    'M-5 5 V2 Q-5 -2 -1.5 -3 V-6 H1.5 V-3 Q5 -2 5 2 V5 H2 V2 Q2 0 0 0 Q-2 0 -2 2 V5 Z',
    dot(0, -3.9) + dot(-3.3, 2.4) + dot(3.3, 2.4),
    'M5 -8 L-1 -5 L4 -2 L-1 1 L4 4 L-4 8 L-5 6 L0 4 L-5 1 L0 -2 L-5 -5 L1 -8 Z',
    dot(0, -3.4) + dot(0, 3.2),
    rect(-5.4, -5.5, 2.6, 11) + dot(2.8, -3.4) + dot(2.8, 3.2),
    arc(turn=2),
    'M0 -5 L4 0 L0 5 L-4 0 Z',
    S,
    arc(turn=1),
    CHEVRON,
    arc(turn=3) + dot(-3.8, -3.3),
    arc(),
    arc(),
    arc(-4) + arc(4),
    dot(-5.5, -1.3, 3.9) + dot(5.5, -1.3, 3.9) +
    'M-4 0 L0 5 L-2 6 L-6 2 Z M4 0 L6 2 L2 6 L0 5 Z |' +
    dot(-5.5, -1.3, 2.4) + dot(5.5, -1.3, 2.4),
    dot(0.8, -1.2, 4.3) + 'M-1 0 L0 2 L-4 6 L-6 4 Z |' + dot(0.8, -1.2, 2.6),
    'M-4 -5 H-1 V0 Q1 2 2 -1 V-5 H5 V-1 Q5 5 -1 3 V7 H-4 Z',
    FORK,
    ANGLE,
    CHEVRON,
    arc(turn=3),
    arc(-4, 3) + arc(4, 3),
    'M4 -6 V-3 L0 -2 L4 2 L2 5 L-4 6 V3 L0 2 L-4 -2 L-2 -5 Z',
    arc(turn=1),
    dot(-1, -1.2, 4.3) + 'M1 0 L5 4 L3 6 L-1 2 Z |' + dot(-1, -1.2, 2.6),
    FORK,
    CHEVRON,
    ANGLE,
    arc(turn=2),
    S,
    ring(0, 0, 3.9),
), strict=True))

VOWELS = {
    0x05B0: ('vowel', dot(0, 2.2) + dot(0, 8.6)),
    0x05B1: ('vowel', dot(-7, 2.2) + dot(-1, 2.2) + dot(-4, 7.2) + dot(5.5, 2.2) + dot(5.5, 8.6)),
    0x05B2: ('vowel', rect(-9, 1, 11.5, 2.4) + dot(7, 2.2) + dot(7, 8.6)),
    0x05B3: ('vowel', rect(-9, 1, 11, 2.4) + rect(-5, 2.5, 2.6, 5.6) + dot(7, 2.2) + dot(7, 8.6)),
    0x05B4: ('vowel', dot(0, 2.2)),
    0x05B5: ('vowel', dot(-3.35, 2.2) + dot(3.35, 2.2)),
    0x05B6: ('vowel', dot(-3.35, 2.2) + dot(3.35, 2.2) + dot(0, 7.2)),
    0x05B7: ('vowel', rect(-6.2, 0.6, 12.4, 2.45)),
    0x05B8: ('vowel', QAMATS),
    0x05B9: ('holam', dot(0, -2.2)),
    0x05BA: ('holam_vav', dot(0, -2.2)),
    0x05BB: ('vowel', dot(-4.4, 2.1, 1.95) + dot(0, 5.7, 1.95) + dot(4.4, 9.3, 1.95)),
    0x05BC: ('inside', dot(0, 0, 2.7)),
    0x05BD: ('meteg', rect(-1.2, 0, 2.4, 9.2)),
    0x05BF: ('upper', rect(-5.3, -2.3, 10.6, 2.3)),
    0x05C1: ('shin', dot(0, -2.2)),
    0x05C2: ('sin', dot(0, -2.2)),
    0x05C4: ('upper', dot(0, -2.2)),
    0x05C5: ('lower', dot(0, 2.2)),
    0x05C7: ('vowel', QAMATS + rect(-2.7, 6.2, 5.4, 1.8)),
    0xFB1E: ('upper', dot(0, -2.2)),
}


def all_marks():
    result = VOWELS.copy()
    leading = {0x059A, 0x059D, 0x05A0, 0x05AB, 0x05AD}
    trailing = {0x0592, 0x0599, 0x05AE}
    for cp, path in ACCENTS.items():
        category = 'below' if unicodedata.combining(chr(cp)) in (220, 222) else 'above'
        if cp in leading:
            category += '_right'
        if cp in trailing:
            category += '_left'
        result[cp] = category, path
    return result
