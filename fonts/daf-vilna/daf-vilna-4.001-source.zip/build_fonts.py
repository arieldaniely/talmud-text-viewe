"""Build manually authored contours with reference-compatible advance widths."""

from dataclasses import dataclass
import json
import sys
from pathlib import Path
from unicodedata import normalize

from fontTools.feaLib.builder import addOpenTypeFeaturesFromString
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.areaPen import AreaPen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.reverseContourPen import ReverseContourPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.svgLib.path import parse_path
from fontTools.ttLib.tables._g_l_y_f import flagOverlapSimple

from letters_v4 import GEMARA, GEMARA_LAMED_SHORT, RASHI, RASHI_LAMED_SHORT
from letters import GEMARA as LEGACY_GEMARA, RASHI as LEGACY_RASHI
from marks import all_marks, dot
from symbols import LATIN, NUMERALS, PUNCTUATION

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / '.deps'))
SCALE = 10
BASELINE = 64
MARKS = all_marks()


@dataclass(frozen=True)
class Face:
    role: str
    hebrew_name: str
    width: float
    height: float
    space: int
    letters: dict
    short_lamed: str
    spacing: dict
    tracking: int = 0


REFERENCE_METRICS = json.loads((ROOT / 'reference-metrics.json').read_text(encoding='utf-8'))
FACES = (
    Face('Gemara', 'דף וילנה גמרא V4', 1, 1, 166, GEMARA, GEMARA_LAMED_SHORT, {}),
    Face('Rashi', 'דף וילנה רש״י V4', 1, 1, 194, RASHI, RASHI_LAMED_SHORT, {}),
    Face('Tosafot', 'דף וילנה תוספות V4', 1, 1, 194, RASHI, RASHI_LAMED_SHORT, {}),
)


def glyph_name(cp):
    return f'uni{cp:04X}'


def draw(path, matrix):
    """Set the contour winding for TrueType and return exact curve bounds."""
    pen = TTGlyphPen(None)
    bounds_pen = BoundsPen(None)
    outer, *holes = path.split('|')
    for part, is_hole in [(outer, False), *((hole, True) for hole in holes)]:
        for contour in part.split('M')[1:]:
            contour = 'M' + contour
            area = AreaPen()
            parse_path(contour, TransformPen(area, matrix))
            if not area.value:
                raise ValueError(f'Zero-area contour: {contour}')
            parse_path(contour, TransformPen(bounds_pen, matrix))
            winding_pen = ReverseContourPen(pen) if (area.value > 0) != is_hole else pen
            curve_pen = Cu2QuPen(winding_pen, max_err=0.65)
            parse_path(contour, TransformPen(curve_pen, matrix))
    glyph = pen.glyph()
    if glyph.numberOfContours > 1:
        glyph.flags[0] |= flagOverlapSimple
    return glyph, bounds_pen.bounds


def design_bounds(path):
    pen = BoundsPen(None)
    for part in path.split('|'):
        parse_path(part, pen)
    return pen.bounds


def anchor(x, y):
    return f'<anchor {round(x)} {round(y)}>'


def mark_layout(bounds, base_anchors):
    accents = {category: [] for category, _ in MARKS.values()}
    for cp, (category, _) in MARKS.items():
        accents[category].append(glyph_name(cp))
    lines = ['languagesystem DFLT dflt;', 'languagesystem hebr dflt;', 'languagesystem latn dflt;']

    for category, names in accents.items():
        for name in names:
            _, bottom, _, top = bounds[name]
            y = top if category in ('vowel', 'meteg', 'lower') or category.startswith('below') else bottom
            if category == 'inside':
                y = 0
            lines.append(f'markClass {name} {anchor(0, y)} @mc_{category};')

    lines.append('feature mark {')
    for name, points in base_anchors.items():
        for category, (x, y) in points.items():
            lines.append(f'pos base {name} {anchor(x, y)} mark @mc_{category};')
    lines.append('} mark;')

    # Keep the OpenType lookups selective so that dagesh and unrelated marks
    # between a vowel and an accent do not interrupt mark-to-mark attachment.
    lower = accents['vowel'] + accents['lower']
    upper = accents['holam'] + accents['holam_vav'] + accents['shin'] + accents['sin'] + accents['upper']
    stacking = (
        ('UnderVowel', lower, 'below', -22, 0),
        ('MetegBesideVowel', lower, 'meteg', 0, -1),
        ('OverPoints', upper, 'above', 22, 0),
        ('ExtraAbove', accents['above'], 'above', 22, 0),
        ('ExtraBelow', accents['below'], 'below', -22, 0),
    )
    lines.append('feature mkmk {')
    for lookup, parents, child, gap, use_left in stacking:
        group = ' '.join(sorted(set(parents + accents[child])))
        lines.extend((f'@set{lookup} = [{group}];', f'lookup {lookup} {{',
                      f'lookupflag UseMarkFilteringSet @set{lookup};'))
        for parent in parents:
            left, bottom, _, top = bounds[parent]
            x = left - 32 if use_left else 0
            y = (top if gap > 0 else bottom) + gap
            if use_left:
                y = top
            lines.append(f'pos mark {parent} {anchor(x, y)} mark @mc_{child};')
        lines.append(f'}} {lookup};')
    lines.append('} mkmk;')
    return lines


# Coordinates inside letter counters and away from their stems. Values are
# expressed on the design grid before spacing and scaling each face.
GEMARA_DAGESH = dict(zip(GEMARA, (
    (24, 51), (23, 36), (7, 37), (24, 37), (27, 43), (5, 38), (1.5, 37),
    (25, 39), (24, 39), (5, 36), (34, 51), (25, 36), (25, 33), (25, 39),
    (25, 39), (2.5, 38), (9, 39), (25, 39), (24, 35), (32, 33), (32, 35),
    (21, 26), (26, 28), (27, 36), (28, 37), (31, 43), (32, 42),
), strict=True))
RASHI_DAGESH = dict(zip(RASHI, (
    (26, 39), (15, 38), (15, 33), (22, 35), (24, 36), (4, 38), (3, 37),
    (25, 40), (31, 40), (7, 34), (18, 42), (24, 36), (16, 36), (26, 39),
    (30, 39), (6, 36), (11, 39), (28, 39), (28, 37), (21, 29), (29, 36),
    (12, 39), (19, 37), (28, 39), (24, 40), (26, 38), (29, 41),
), strict=True))


def points_for_letter(char, matrix, extent, dagesh):
    left, bottom, right, top = extent
    sx, _, _, sy, dx, dy = matrix
    center = (left + right) / 2
    below = min(-54, bottom - 42)
    above = top + 45
    x, y = dagesh.get(char, (26, 38))
    if char in GEMARA:
        legacy = LEGACY_GEMARA if dagesh is GEMARA_DAGESH else LEGACY_RASHI
        current = GEMARA if dagesh is GEMARA_DAGESH else RASHI
        old_left, old_top, old_right, old_bottom = design_bounds(legacy[char])
        new_left, new_top, new_right, new_bottom = design_bounds(current[char])
        x = new_left + (x-old_left)/(old_right-old_left)*(new_right-new_left)
        y = new_top + (y-old_top)/(old_bottom-old_top)*(new_bottom-new_top)
    vowel_x, vowel_y = (center, below)
    if char == 'ך':
        vowel_x, vowel_y = left + 50, 120
        x, y = None, None
    inside = (left + 72, 280) if char == 'ך' else (x * sx + dx, y * sy + dy)
    return {
        'vowel': (vowel_x, vowel_y),
        'below': (center, below),
        'below_right': (max(right + 65, center + 185), below),
        'lower': (center, below - 16),
        'meteg': (center - 62, below),
        'inside': inside,
        'above': (center, above),
        'above_left': (left + 10, above + 100),
        'above_right': (right - 12, above + 100),
        'holam': (left - 24, above),
        'holam_vav': (right - 22, above),
        'shin': (right - 54, above),
        'sin': (left + 47, above),
        'upper': (center, above),
    }


def build(face):
    glyphs, metrics, cmap, bounds, base_anchors = {}, {}, {}, {}, {}

    def put(name, path, matrix, width, cp=None):
        glyph, extent = draw(path, matrix)
        glyph.recalcBounds(None)
        glyphs[name] = glyph
        bounds[name] = extent
        metrics[name] = (round(width), glyph.xMin if extent else 0)
        if cp is not None:
            cmap[cp] = name
        return extent

    def text_glyph(char, path, *, fixed=None, name=None, shift=0):
        cp = ord(char)
        is_hebrew = char in face.letters or char in '׆ׯװױײ'
        sx = SCALE * (face.width if is_hebrew else 0.94)
        sy = -SCALE * (face.height if is_hebrew else 0.96)
        left, upper, right, lower = design_bounds(path)
        reference = REFERENCE_METRICS[face.role].get(char)
        if reference:
            x0, y0, x1, y1 = reference['bounds']
            sx = (x1-x0)/(right-left)
            sy = -(y1-y0)/(lower-upper)
            advance = reference['advance']
            dx, dy = x0-left*sx, y1-upper*sy
        else:
            width = (right-left)*sx
            advance = fixed or width+55
            dx, dy = (advance-width)/2-left*sx+shift, -BASELINE*sy
        matrix = (sx, 0, 0, sy, dx, dy)
        name = name or glyph_name(cp)
        extent = put(name, path, matrix, advance, cp if name == glyph_name(cp) else None)
        return matrix, extent

    put('.notdef', 'M60 0 H440 V580 H60 Z | M112 52 H388 V528 H112 Z',
        (1, 0, 0, 1, 0, 0), 500)
    put('space', '', (1, 0, 0, 1, 0, 0), face.space, 0x20)
    cmap[0xA0] = 'space'
    put('uni200B', '', (1, 0, 0, 1, 0, 0), 0, 0x200B)
    cmap.update(dict.fromkeys((0x034F, 0x200C, 0x200D, 0x200E, 0x200F, 0x2060, 0xFEFF), 'uni200B'))

    for char, path in (LATIN | NUMERALS | PUNCTUATION).items():
        text_glyph(char, path)
    for char, path in NUMERALS.items():
        text_glyph(char, path, fixed=472, name=glyph_name(ord(char)) + '.tab')

    dagesh = GEMARA_DAGESH if face.role == 'Gemara' else RASHI_DAGESH
    for char, path in face.letters.items():
        name = glyph_name(ord(char))
        matrix, extent = text_glyph(char, path)
        base_anchors[name] = points_for_letter(char, matrix, extent, dagesh)
        if char == 'ל':
            alternate = 'uni05DC.short'
            # Keep exactly the same advance and x origin through a substitution.
            short_extent = put(alternate, face.short_lamed, matrix, metrics[name][0])
            base_anchors[alternate] = points_for_letter(char, matrix, short_extent, dagesh)

    for cp, (_, path) in MARKS.items():
        put(glyph_name(cp), path, (SCALE, 0, 0, -SCALE, 0, 0), 0, cp)

    circle = ''.join(dot(x, y, 2.1) for x, y in (
        (14, 15), (25, 12), (36, 15), (44, 23), (47, 35), (44, 47),
        (36, 55), (25, 58), (14, 55), (6, 47), (3, 35), (6, 23),
    ))
    matrix, extent = text_glyph('◌', circle)
    base_anchors['uni25CC'] = points_for_letter('◌', matrix, extent, dagesh)

    substitutions = []
    for cp, spelling in {0x05F0: 'וו', 0x05F1: 'וי', 0x05F2: 'יי'}.items():
        add_encoded_form(cp, spelling, glyphs, metrics, cmap, substitutions)
    for cp in range(0xFB1D, 0xFB50):
        spelling = normalize('NFKD', chr(cp))
        if spelling != chr(cp) and all(ord(char) in cmap for char in spelling):
            add_encoded_form(cp, spelling, glyphs, metrics, cmap, substitutions)

    family = f'Daf Vilna {face.role} V4'
    ps_name = f'DafVilna{face.role}V4-Regular'
    fb = FontBuilder(1000, isTTF=True)
    fb.setupGlyphOrder(list(glyphs))
    fb.setupCharacterMap(cmap)
    fb.setupGlyf(glyphs)
    fb.setupHorizontalMetrics(metrics)
    fb.setupHorizontalHeader(ascent=950, descent=-380, lineGap=0)
    fb.setupNameTable({
        'familyName': {'en': family, 'he': face.hebrew_name},
        'styleName': {'en': 'Regular', 'he': 'רגיל'},
        'fullName': {'en': family, 'he': face.hebrew_name},
        'psName': ps_name,
        'uniqueFontIdentifier': f'{ps_name};4.001',
        'licenseDescription': 'GNU General Public License version 3 (GPL-3.0-only).',
        'licenseInfoURL': 'https://www.gnu.org/licenses/gpl-3.0.html',
        'version': 'Version 4.001',
        'description': 'Hebrew outlines authored as original paths, matched to reference dimensions.',
    })
    fb.setupOS2(
        version=4, sTypoAscender=950, sTypoDescender=-380, sTypoLineGap=0,
        usWinAscent=1150, usWinDescent=660, fsSelection=0xC0,
        usWeightClass=400, usWidthClass=5, fsType=0, sxHeight=390, sCapHeight=536,
        panose={'bFamilyType': 2, 'bSerifStyle': 2, 'bWeight': 5, 'bProportion': 3,
                'bContrast': 6, 'bStrokeVariation': 3, 'bArmStyle': 2, 'bLetterForm': 2,
                'bMidline': 2, 'bXHeight': 3},
    )
    fb.setupPost()
    from fontTools.ttLib.removeOverlaps import removeOverlaps
    removeOverlaps(fb.font, ignoreErrors=False)
    fb.font.recalcTimestamp = False
    fb.setupHead(created=3876768000, modified=3876768000, lowestRecPPEM=9, fontRevision=4.001)

    features = mark_layout(bounds, base_anchors)
    features.extend(('feature ccmp {',
                     'lookup PresentationForms {', *substitutions[3:], '} PresentationForms;',
                     'lookup YiddishForms {', *substitutions[:3], '} YiddishForms;',
                     '} ccmp;',
                     'feature ss01 {',
                     'featureNames { name "Folded lamed"; name 3 1 0x040D "למד כפופה"; };',
                     'sub uni05DC by uni05DC.short;', '} ss01;',
                     'feature tnum {',
                     *(f'sub {glyph_name(ord(ch))} by {glyph_name(ord(ch))}.tab;' for ch in NUMERALS),
                     '} tnum;', 'feature kern {'))
    for first, second, amount in (
        ('A', 'V', -42), ('A', 'W', -37), ('A', 'Y', -44), ('V', 'A', -42),
        ('W', 'A', -33), ('Y', 'A', -42), ('T', 'a', -45), ('T', 'o', -46),
        ('Y', 'o', -40), ('L', 'T', -39), ('P', 'A', -31), 
    ):
        features.append(f'pos {glyph_name(ord(first))} {glyph_name(ord(second))} {amount};')
    features.append('} kern;')
    addOpenTypeFeaturesFromString(fb.font, '\n'.join(features))

    out = ROOT / 'fonts' / 'v4'
    out.mkdir(parents=True, exist_ok=True)
    fb.font.save(out / f'{ps_name}.ttf')
    fb.font.flavor = 'woff2'
    fb.font.save(out / f'{ps_name}.woff2')
    for extension in ('ttf', 'woff2'):
        (ROOT / 'fonts' / f'DafVilna{face.role}-Regular.{extension}').write_bytes(
            (out / f'{ps_name}.{extension}').read_bytes())


def add_encoded_form(cp, spelling, glyphs, metrics, cmap, substitutions):
    """Provide a font-level decomposition and a visible unshaped fallback."""
    name = glyph_name(cp)
    pen = TTGlyphPen(glyphs)
    width = 0
    names = [cmap[ord(char)] for char in spelling]
    ink_left = []
    for component in reversed(names):
        advance, lsb = metrics[component]
        if advance and glyphs[component].numberOfContours:
            pen.addComponent(component, (1, 0, 0, 1, width, 0))
            ink_left.append(width + lsb)
        width += advance
    glyphs[name] = pen.glyph()
    metrics[name] = (width, min(ink_left, default=0))
    cmap[cp] = name
    substitutions.append(f'sub {name} by {" ".join(names)};')


if __name__ == '__main__':
    for design in FACES:
        build(design)
